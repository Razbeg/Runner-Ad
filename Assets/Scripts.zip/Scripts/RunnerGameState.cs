namespace PlayableRunner
{
    public enum RunnerGameState
    { 
        Start,
        Tutorial,
        Play,
        Fail,
        End
    }
}